from modelos import ( Autor, Libro, Estudiante, Prestamo ) 
from base_datos import ( abrir_base_datos, inicializar_base_datos, cerrar_base_datos )
import transaction


def main():
    
    db, connection, root = abrir_base_datos() 

    inicializar_base_datos(root) 

    print("===================================") 
    print(" SISTEMA DE BIBLIOTECA CON ZODB") 
    print("===================================")

    # ---------------------------------- # Crear autores # ---------------------------------- 
    
    autor1 = Autor( 1, "Gabriel García Márquez", "Colombia" ) 
    autor2 = Autor( 2, "Julio Verne", "Francia" ) 

    root.autores[autor1.id_autor] = autor1 
    root.autores[autor2.id_autor] = autor2 

    # ---------------------------------- # Crear libros # ---------------------------------- 

    libro1 = Libro( "9780307474728", "Cien años de soledad", 1967, "Novela", autor1 ) 
    libro2 = Libro( "9780199538474", "Viaje al centro de la Tierra", 1864, "Aventura", autor2 ) 

    root.libros[libro1.isbn] = libro1 
    root.libros[libro2.isbn] = libro2 

    # ---------------------------------- # Crear estudiantes # ---------------------------------- 

    estudiante1 = Estudiante( "A001", "Ana López", "Ingeniería en Sistemas", "ana@universidad.edu.mx" ) 
    estudiante2 = Estudiante( "A002", "Carlos Pérez", "Ingeniería Informática", "carlos@universidad.edu.mx" ) 

    root.estudiantes[ estudiante1.matricula ] = estudiante1 
    root.estudiantes[ estudiante2.matricula ] = estudiante2 

    transaction.commit() 

    print("\nAutores registrados:") 

    for autor in root.autores.values(): 
        print( autor.id_autor, autor.mostrar_info() ) 

    print("\nLibros registrados:") 

    for libro in root.libros.values(): 
        print( libro.isbn, libro.titulo, "- Disponible:", libro.esta_disponible() ) 

    print("\nEstudiantes registrados:") 

    for estudiante in root.estudiantes.values(): 
        print( estudiante.matricula, estudiante.mostrar_info() ) 

    cerrar_base_datos(db, connection)


if __name__ == "__main__":
    main()